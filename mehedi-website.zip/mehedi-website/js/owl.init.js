//*********************/ 
//   Owl Carousel     */
//*********************/ 
$("#clients-testi").owlCarousel({
  autoPlay: 3000,
  items: 2,
  itemsDesktop : [1024,2],
  itemsDesktopSmall : [900,2],
  itemsTablet: [600,1],
});
